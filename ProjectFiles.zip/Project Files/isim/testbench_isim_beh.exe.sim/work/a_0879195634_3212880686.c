/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;
static const char *ng3 = "C:/Users/Grant/Documents/VHDL/AlarmClock/timeToBCD.vhd";

char *ieee_p_1242562249_sub_1919365254_1035706684(char *, char *, char *, char *, int );


char *work_a_0879195634_3212880686_sub_4007778001_3057020925(char *t1, char *t2, char *t3)
{
    char t4[368];
    char t5[24];
    char t6[16];
    char t13[8];
    char t18[16];
    char t24[8];
    char t29[16];
    char t67[16];
    char t68[16];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    int t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t30;
    char *t31;
    int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned char t41;
    char *t42;
    int t43;
    int t44;
    char *t45;
    char *t46;
    int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    int t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    char *t55;
    char *t56;
    int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned char t65;
    unsigned char t66;
    unsigned int t69;
    unsigned int t70;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 7;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t9 = (0 - 7);
    t10 = (t9 * -1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t4 + 4U);
    t11 = ((STD_STANDARD) + 384);
    t12 = (t8 + 88U);
    *((char **)t12) = t11;
    t14 = (t8 + 56U);
    *((char **)t14) = t13;
    *((int *)t13) = 0;
    t15 = (t8 + 80U);
    *((unsigned int *)t15) = 4U;
    t16 = xsi_get_transient_memory(8U);
    memset(t16, 0, 8U);
    t17 = t16;
    memset(t17, (unsigned char)2, 8U);
    t19 = (t18 + 0U);
    t20 = (t19 + 0U);
    *((int *)t20) = 7;
    t20 = (t19 + 4U);
    *((int *)t20) = 0;
    t20 = (t19 + 8U);
    *((int *)t20) = -1;
    t21 = (0 - 7);
    t10 = (t21 * -1);
    t10 = (t10 + 1);
    t20 = (t19 + 12U);
    *((unsigned int *)t20) = t10;
    t20 = (t4 + 124U);
    t22 = ((IEEE_P_2592010699) + 4024);
    t23 = (t20 + 88U);
    *((char **)t23) = t22;
    t25 = (t20 + 56U);
    *((char **)t25) = t24;
    memcpy(t24, t16, 8U);
    t26 = (t20 + 64U);
    *((char **)t26) = t18;
    t27 = (t20 + 80U);
    *((unsigned int *)t27) = 8U;
    t28 = (t6 + 12U);
    t10 = *((unsigned int *)t28);
    t10 = (t10 * 1U);
    t30 = (t29 + 0U);
    t31 = (t30 + 0U);
    *((int *)t31) = 7;
    t31 = (t30 + 4U);
    *((int *)t31) = 0;
    t31 = (t30 + 8U);
    *((int *)t31) = -1;
    t32 = (0 - 7);
    t33 = (t32 * -1);
    t33 = (t33 + 1);
    t31 = (t30 + 12U);
    *((unsigned int *)t31) = t33;
    t31 = (t4 + 244U);
    t34 = ((IEEE_P_2592010699) + 4024);
    t35 = (t31 + 88U);
    *((char **)t35) = t34;
    t36 = (char *)alloca(t10);
    t37 = (t31 + 56U);
    *((char **)t37) = t36;
    memcpy(t36, t3, t10);
    t38 = (t31 + 64U);
    *((char **)t38) = t29;
    t39 = (t31 + 80U);
    *((unsigned int *)t39) = t10;
    t40 = (t5 + 4U);
    t41 = (t3 != 0);
    if (t41 == 1)
        goto LAB3;

LAB2:    t42 = (t5 + 12U);
    *((char **)t42) = t6;
    t43 = 0;
    t44 = 7;

LAB4:    if (t43 <= t44)
        goto LAB5;

LAB7:    t7 = (t20 + 56U);
    t11 = *((char **)t7);
    t7 = (t18 + 12U);
    t10 = *((unsigned int *)t7);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t11, t10);
    t12 = (t18 + 0U);
    t9 = *((int *)t12);
    t14 = (t18 + 4U);
    t21 = *((int *)t14);
    t15 = (t18 + 8U);
    t32 = *((int *)t15);
    t16 = (t2 + 0U);
    t17 = (t16 + 0U);
    *((int *)t17) = t9;
    t17 = (t16 + 4U);
    *((int *)t17) = t21;
    t17 = (t16 + 8U);
    *((int *)t17) = t32;
    t43 = (t21 - t9);
    t33 = (t43 * t32);
    t33 = (t33 + 1);
    t17 = (t16 + 12U);
    *((unsigned int *)t17) = t33;

LAB1:    return t0;
LAB3:    *((char **)t40) = t3;
    goto LAB2;

LAB5:    t45 = (t20 + 56U);
    t46 = *((char **)t45);
    t45 = (t18 + 0U);
    t47 = *((int *)t45);
    t33 = (t47 - 6);
    t48 = (t33 * 1U);
    t49 = (0 + t48);
    t50 = (t46 + t49);
    t51 = (0 - 6);
    t52 = (t51 * -1);
    t52 = (t52 + 1);
    t53 = (1U * t52);
    t54 = xsi_get_transient_memory(t53);
    memcpy(t54, t50, t53);
    t55 = (t20 + 56U);
    t56 = *((char **)t55);
    t55 = (t18 + 0U);
    t57 = *((int *)t55);
    t58 = (t57 - 7);
    t59 = (t58 * 1U);
    t60 = (0 + t59);
    t61 = (t56 + t60);
    t62 = (0 - 6);
    t63 = (t62 * -1);
    t63 = (t63 + 1);
    t64 = (1U * t63);
    memcpy(t61, t54, t64);
    t7 = (t31 + 56U);
    t11 = *((char **)t7);
    t7 = (t29 + 0U);
    t9 = *((int *)t7);
    t12 = (t29 + 8U);
    t21 = *((int *)t12);
    t32 = (7 - t9);
    t10 = (t32 * t21);
    t33 = (1U * t10);
    t48 = (0 + t33);
    t14 = (t11 + t48);
    t41 = *((unsigned char *)t14);
    t15 = (t20 + 56U);
    t16 = *((char **)t15);
    t15 = (t18 + 0U);
    t47 = *((int *)t15);
    t17 = (t18 + 8U);
    t51 = *((int *)t17);
    t57 = (0 - t47);
    t49 = (t57 * t51);
    t52 = (1U * t49);
    t53 = (0 + t52);
    t19 = (t16 + t53);
    *((unsigned char *)t19) = t41;
    t7 = (t31 + 56U);
    t11 = *((char **)t7);
    t7 = (t29 + 0U);
    t9 = *((int *)t7);
    t10 = (t9 - 6);
    t33 = (t10 * 1U);
    t48 = (0 + t33);
    t12 = (t11 + t48);
    t21 = (0 - 6);
    t49 = (t21 * -1);
    t49 = (t49 + 1);
    t52 = (1U * t49);
    t14 = xsi_get_transient_memory(t52);
    memcpy(t14, t12, t52);
    t15 = (t31 + 56U);
    t16 = *((char **)t15);
    t15 = (t29 + 0U);
    t32 = *((int *)t15);
    t53 = (t32 - 7);
    t58 = (t53 * 1U);
    t59 = (0 + t58);
    t17 = (t16 + t59);
    t47 = (0 - 6);
    t60 = (t47 * -1);
    t60 = (t60 + 1);
    t63 = (1U * t60);
    memcpy(t17, t14, t63);
    t7 = (t31 + 56U);
    t11 = *((char **)t7);
    t7 = (t29 + 0U);
    t9 = *((int *)t7);
    t12 = (t29 + 8U);
    t21 = *((int *)t12);
    t32 = (0 - t9);
    t10 = (t32 * t21);
    t33 = (1U * t10);
    t48 = (0 + t33);
    t14 = (t11 + t48);
    *((unsigned char *)t14) = (unsigned char)2;
    t65 = (t43 < 7);
    if (t65 == 1)
        goto LAB11;

LAB12:    t41 = (unsigned char)0;

LAB13:    if (t41 != 0)
        goto LAB8;

LAB10:
LAB9:    t65 = (t43 < 7);
    if (t65 == 1)
        goto LAB17;

LAB18:    t41 = (unsigned char)0;

LAB19:    if (t41 != 0)
        goto LAB14;

LAB16:
LAB15:
LAB6:    if (t43 == t44)
        goto LAB7;

LAB20:    t9 = (t43 + 1);
    t43 = t9;
    goto LAB4;

LAB8:    t17 = (t20 + 56U);
    t19 = *((char **)t17);
    t17 = (t18 + 0U);
    t32 = *((int *)t17);
    t53 = (t32 - 3);
    t58 = (t53 * 1U);
    t59 = (0 + t58);
    t22 = (t19 + t59);
    t23 = (t68 + 0U);
    t25 = (t23 + 0U);
    *((int *)t25) = 3;
    t25 = (t23 + 4U);
    *((int *)t25) = 0;
    t25 = (t23 + 8U);
    *((int *)t25) = -1;
    t47 = (0 - 3);
    t60 = (t47 * -1);
    t60 = (t60 + 1);
    t25 = (t23 + 12U);
    *((unsigned int *)t25) = t60;
    t25 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t67, t22, t68, 3);
    t26 = (t20 + 56U);
    t27 = *((char **)t26);
    t26 = (t18 + 0U);
    t51 = *((int *)t26);
    t60 = (t51 - 3);
    t63 = (t60 * 1U);
    t64 = (0 + t63);
    t28 = (t27 + t64);
    t30 = (t67 + 12U);
    t69 = *((unsigned int *)t30);
    t70 = (1U * t69);
    memcpy(t28, t25, t70);
    goto LAB9;

LAB11:    t7 = (t20 + 56U);
    t11 = *((char **)t7);
    t7 = (t18 + 0U);
    t9 = *((int *)t7);
    t10 = (t9 - 3);
    t33 = (t10 * 1U);
    t48 = (0 + t33);
    t12 = (t11 + t48);
    t21 = (0 - 3);
    t49 = (t21 * -1);
    t49 = (t49 + 1);
    t52 = (1U * t49);
    t14 = (t1 + 6132);
    t16 = ((IEEE_P_2592010699) + 4024);
    t66 = xsi_vhdl_greater(t16, t12, t52, t14, 4U);
    t41 = t66;
    goto LAB13;

LAB14:    t17 = (t20 + 56U);
    t19 = *((char **)t17);
    t17 = (t18 + 0U);
    t32 = *((int *)t17);
    t53 = (t32 - 7);
    t58 = (t53 * 1U);
    t59 = (0 + t58);
    t22 = (t19 + t59);
    t23 = (t68 + 0U);
    t25 = (t23 + 0U);
    *((int *)t25) = 7;
    t25 = (t23 + 4U);
    *((int *)t25) = 4;
    t25 = (t23 + 8U);
    *((int *)t25) = -1;
    t47 = (4 - 7);
    t60 = (t47 * -1);
    t60 = (t60 + 1);
    t25 = (t23 + 12U);
    *((unsigned int *)t25) = t60;
    t25 = ieee_p_1242562249_sub_1919365254_1035706684(IEEE_P_1242562249, t67, t22, t68, 3);
    t26 = (t20 + 56U);
    t27 = *((char **)t26);
    t26 = (t18 + 0U);
    t51 = *((int *)t26);
    t60 = (t51 - 7);
    t63 = (t60 * 1U);
    t64 = (0 + t63);
    t28 = (t27 + t64);
    t30 = (t67 + 12U);
    t69 = *((unsigned int *)t30);
    t70 = (1U * t69);
    memcpy(t28, t25, t70);
    goto LAB15;

LAB17:    t7 = (t20 + 56U);
    t11 = *((char **)t7);
    t7 = (t18 + 0U);
    t9 = *((int *)t7);
    t10 = (t9 - 7);
    t33 = (t10 * 1U);
    t48 = (0 + t33);
    t12 = (t11 + t48);
    t21 = (4 - 7);
    t49 = (t21 * -1);
    t49 = (t49 + 1);
    t52 = (1U * t49);
    t14 = (t1 + 6136);
    t16 = ((IEEE_P_2592010699) + 4024);
    t66 = xsi_vhdl_greater(t16, t12, t52, t14, 4U);
    t41 = t66;
    goto LAB19;

LAB21:;
}

static void work_a_0879195634_3212880686_p_0(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(44, ng3);

LAB3:    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = work_a_0879195634_3212880686_sub_4007778001_3057020925(t0, t1, t3);
    t4 = (t1 + 12U);
    t5 = *((unsigned int *)t4);
    t5 = (t5 * 1U);
    t6 = (8U != t5);
    if (t6 == 1)
        goto LAB5;

LAB6:    t7 = (t0 + 3920);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t2, 8U);
    xsi_driver_first_trans_fast_port(t7);

LAB2:    t12 = (t0 + 3808);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t5, 0);
    goto LAB6;

}

static void work_a_0879195634_3212880686_p_1(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(45, ng3);

LAB3:    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = work_a_0879195634_3212880686_sub_4007778001_3057020925(t0, t1, t3);
    t4 = (t1 + 12U);
    t5 = *((unsigned int *)t4);
    t5 = (t5 * 1U);
    t6 = (8U != t5);
    if (t6 == 1)
        goto LAB5;

LAB6:    t7 = (t0 + 3984);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t2, 8U);
    xsi_driver_first_trans_fast_port(t7);

LAB2:    t12 = (t0 + 3824);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t5, 0);
    goto LAB6;

}

static void work_a_0879195634_3212880686_p_2(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    xsi_set_current_line(46, ng3);

LAB3:    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = work_a_0879195634_3212880686_sub_4007778001_3057020925(t0, t1, t3);
    t4 = (t1 + 12U);
    t5 = *((unsigned int *)t4);
    t5 = (t5 * 1U);
    t6 = (8U != t5);
    if (t6 == 1)
        goto LAB5;

LAB6:    t7 = (t0 + 4048);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t2, 8U);
    xsi_driver_first_trans_fast_port(t7);

LAB2:    t12 = (t0 + 3840);
    *((int *)t12) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t5, 0);
    goto LAB6;

}


extern void work_a_0879195634_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0879195634_3212880686_p_0,(void *)work_a_0879195634_3212880686_p_1,(void *)work_a_0879195634_3212880686_p_2};
	static char *se[] = {(void *)work_a_0879195634_3212880686_sub_4007778001_3057020925};
	xsi_register_didat("work_a_0879195634_3212880686", "isim/testbench_isim_beh.exe.sim/work/a_0879195634_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
